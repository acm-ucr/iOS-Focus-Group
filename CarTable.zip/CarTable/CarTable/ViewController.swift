//
//  ViewController.swift
//  CarTable
//
//  Created by james luo on 11/6/19.
//  Copyright © 2019 james luo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

