//
//  ViewController.swift
//  CarTable
//
//  Created by james luo on 11/6/19.
//  Copyright © 2019 james luo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ThreadLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        ThreadLabel.text = ThreadString
        // Do any additional setup after loading the view.
    }


}

